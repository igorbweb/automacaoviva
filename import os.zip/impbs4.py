import os
import requests
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor

# Lista de URLs adicionais para acessar
urls_adicionais = [
    "porto-bello-iv",  # substitua com suas URLs reais
    "viva-residence-alecrim",
]

# Função para fazer download da imagem
def download_image(img_url, img_path):
    response = requests.get(img_url)
    if response.status_code == 200:
        with open(img_path, 'wb') as file:
            file.write(response.content)
        print(f"Imagem {os.path.basename(img_path)} baixada com sucesso em {img_path}")
    else:
        print(f"Erro ao baixar a imagem {os.path.basename(img_path)}")

# URL base
url_base = "https://vivaconstrucoes.com.br/empreendimentos/pronto-para-morar/"

# Cabeçalhos HTTP (opcional, pode ajudar a evitar bloqueios)
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
}

for url_adicional in urls_adicionais:
    full_url = url_base + url_adicional
    response = requests.get(full_url, headers=headers)
    soup = BeautifulSoup(response.content, 'html.parser')
    
    # Criar diretório para o URL adicional
    main_directory = os.path.join("imagens", url_adicional)
    os.makedirs(main_directory, exist_ok=True)
    
    # Selecionar o dropdown de meses e obter as opções válidas
    select_element = soup.find('select', {'id': 'mesAno'})
    options = [option for option in select_element.find_all('option') if option.get('value') and option.get('value') != "Selecione o mês e o ano"]
    
    for option in options:
        month_year = option.text.strip()
        option_value = option['value']
        
        # Criar um diretório para o mês e ano dentro do diretório principal
        directory = os.path.join(main_directory, month_year.replace(" ", "_"))
        os.makedirs(directory, exist_ok=True)
        
        # Depuração: Mostrar opção selecionada
        print(f"Selecionando a opção: {option_value} - {month_year}")
        
        # Fazer uma requisição para a URL com a opção selecionada
        filter_url = f"{full_url}?mesAno={option_value}"
        response = requests.get(filter_url, headers=headers)
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Buscar a div específica do estágio de obra ativo
        active_stage_div = soup.find('div', {'class': 'estagio-obra', 'style': 'display: block;'})
        
        if active_stage_div:
            # Buscar as imagens na div específica
            images = active_stage_div.select('a.item')
            
            # Preparar lista de downloads
            download_tasks = []
            for img in images:
                img_url = img['href']
                img_name = os.path.basename(img_url)
                img_path = os.path.join(directory, img_name)
                download_tasks.append((img_url, img_path))
            
            # Fazer o download das imagens usando threads
            with ThreadPoolExecutor(max_workers=5) as executor:
                executor.map(lambda p: download_image(*p), download_tasks)
        else:
            print(f"Nenhuma imagem encontrada para {month_year}")
